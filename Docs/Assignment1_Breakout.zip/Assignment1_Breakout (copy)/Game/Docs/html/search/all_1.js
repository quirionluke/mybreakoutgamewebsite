var searchData=
[
  ['collides',['Collides',['../classEntity.html#aedb02f3a7501604c34cb58b796873ff8',1,'Entity']]],
  ['createlevel',['CreateLevel',['../classBoard.html#af11cf454515ef90de6c659a79bcbac00',1,'Board::CreateLevel()'],['../classBoard.html#a5238b7d770a9b834b8eff70af43c58b7',1,'Board::CreateLevel(string filepath)']]]
];
