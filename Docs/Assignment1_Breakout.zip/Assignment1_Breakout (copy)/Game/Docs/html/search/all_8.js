var searchData=
[
  ['render',['Render',['../classBall.html#a1103f2193c0e478926eb6af95a65d46e',1,'Ball::Render()'],['../classBoard.html#a2cdb83c07225dd83366ce10ea2978dd8',1,'Board::Render()'],['../classEntity.html#a48b58f16934376de583771ddabcf5bdb',1,'Entity::Render()'],['../classPaddle.html#a166255dfac354af75059ed4a72e1a0ee',1,'Paddle::Render()']]],
  ['run',['Run',['../classGame.html#a96341ca5b54d90adc3ecb3bf0bcd2312',1,'Game']]]
];
