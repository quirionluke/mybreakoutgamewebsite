// ------------------------------------------------------------
// The Breakout Tutorial
// (c) 2015 Rembound.com
// http://rembound.com/articles/the-breakout-tutorial
// ------------------------------------------------------------

#ifndef BALL_H_
#define BALL_H_

#include "Entity.h"

#include <math.h>

// Define a ball speed in pixels per second
const float BALL_SPEED = 550;

///This class is an entity that keeps track of the ball's direction and also how to render it.
class Ball: public Entity {
public:
    Ball(SDL_Renderer* renderer);
    ~Ball();

    ///Updates the position of the ball
    void Update(float delta);
    ///Renders the ball
    void Render(float delta);
    ///Points the ball in a direction
    void SetDirection(float dirx, float diry);

    float dirx, diry;

private:
    SDL_Texture* texture;

};

#endif
