// ------------------------------------------------------------
// The Breakout Tutorial
// (c) 2015 Rembound.com
// http://rembound.com/articles/the-breakout-tutorial
// ------------------------------------------------------------

#ifndef ENTITY_H_
#define ENTITY_H_

#include "SDL2/SDL.h"
#include "SDL2/SDL_image.h"

///The entity class handles basic entities, which is used by the paddle, ball, and bricks during the game.
class Entity {
public:
    Entity(SDL_Renderer* renderer);
    virtual ~Entity();

    ///The dimensions of the given entity
    float x, y, width, height;

    ///Updates the entity every frame
    virtual void Update(float delta);
    ///Renders the entity
    virtual void Render(float delta);
    ///Checks if this entity is currently colliding with another
    bool Collides(Entity* other);
protected:
    SDL_Renderer* renderer;

};

#endif
