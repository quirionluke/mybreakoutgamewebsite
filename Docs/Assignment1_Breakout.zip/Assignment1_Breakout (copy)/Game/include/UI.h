#ifndef SCORE_H_
#define SCORE_H_

#include <string.h>
#include "SDL2/SDL.h"
#include "SDL2/SDL_image.h"
#include "SDL2/SDL_ttf.h"

///Positions the text UI on the screen, which consists of the score number and the amount of lives remaining
class UI {
    public:
        UI(float x, float y, SDL_Renderer* renderer, TTF_Font* font);
        ~UI();

        ///Positions the text UI on the screen and dislays it to the player
        void Draw();
        ///Changes the text to be displayed to the player
        void SetText(char * text);
    private:
        SDL_Renderer* renderer;
		TTF_Font* font;
		SDL_Surface* surface{};
		SDL_Texture* texture{};
		SDL_Rect rect{};

        float x, y;
        int width, height;
        char * text;
};



#endif