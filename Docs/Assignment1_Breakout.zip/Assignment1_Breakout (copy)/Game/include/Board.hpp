#ifndef BOARD_H_
#define BOARD_H_

#include "Entity.h"
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include <fstream>
#include <string>

// Define the dimensions of the board and bricks
#define BOARD_WIDTH 12
#define BOARD_HEIGHT 12
#define BOARD_BRWIDTH 64
#define BOARD_BRHEIGHT 24

// ------------------------------------------------------------
// The Breakout Tutorial
// (c) 2015 Rembound.com
// http://rembound.com/articles/the-breakout-tutorial
// ------------------------------------------------------------

using namespace std;

class Brick {
public:
    bool state;
    int type;
};

///This board class handles the generating of levels, the reading in from files, and the textures of the bricks
class Board: public Entity {
public:
    Board(SDL_Renderer* renderer);
    ~Board();
    ///Updates the board evry frame, which includes the bricks' states
    void Update(float delta);
    ///Renders all of the bricks
    void Render(float delta);
    ///Generates a new default board
    void CreateLevel();
    ///Generates a new board from the given text file
    void CreateLevel(string filepath);

    float brickoffsetx, brickoffsety;

    // Define the two-dimensional array of bricks
    Brick bricks[BOARD_WIDTH][BOARD_HEIGHT];

private:
    SDL_Texture* bricktexture;
    SDL_Texture* sidetexture;
};

#endif