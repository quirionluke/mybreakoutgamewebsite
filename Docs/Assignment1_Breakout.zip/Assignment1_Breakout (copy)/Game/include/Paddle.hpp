// ------------------------------------------------------------
// The Breakout Tutorial
// (c) 2015 Rembound.com
// http://rembound.com/articles/the-breakout-tutorial
// ------------------------------------------------------------

#ifndef PADDLE_H_
#define PADDLE_H_

#include "Entity.h"

const float PADDLE_SPEED = 500;

///The paddle class handles the movement of the paddle that the player controls
class Paddle: public Entity {
public:
    Paddle(SDL_Renderer* renderer);
    ~Paddle();

    ///Updates the paddle every frame, which includes moving it from the player's commands
    void Update(float delta);
    ///Renders the paddle
    void Render(float delta);
    ///Sets the direction of the paddle (left or right)
    void SetDirection(float dirx);

private:
    float dirx;
    SDL_Texture* texture;
};

#endif
