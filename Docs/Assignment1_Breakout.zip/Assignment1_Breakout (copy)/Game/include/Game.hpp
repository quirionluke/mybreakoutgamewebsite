// ------------------------------------------------------------
// The Breakout Tutorial
// (c) 2015 Rembound.com
// http://rembound.com/articles/the-breakout-tutorial
// ------------------------------------------------------------

#ifndef GAME_H_
#define GAME_H_

#include "SDL2/SDL.h"
#include "SDL2/SDL_image.h"
#include "SDL2/SDL_mixer.h"
#include <iostream>
#include <stdio.h>
#include <string>

#include "Board.hpp"
#include "Paddle.hpp"
#include "Ball.h"
#include "UI.h"

using namespace std;

/*!
The Game class is our Resource Manager, it is initialized once when we run the game using ./breakout
*/
class Game {
public:
    Game();
    ~Game();

    /*!
        The init function loads in the window and all of the assets
    */
    bool Init();
    /*!
        The Run function kicks off the game and controls all of the math
    */
    void Run();

private:
    SDL_Window* window;
    SDL_Renderer* renderer;

    SDL_Texture* texture;

    // sounds
    Mix_Chunk* brickHitSound;
    Mix_Chunk* ballLostSound;
    Mix_Music* bgmSound;
    Mix_Music* gameLostSound;
    Mix_Music* gameWonSound;

    // Timing
    unsigned int lasttick, fpstick, fps, framecount;

    string levels[4] = {"Assets/level1.txt", "Assets/level2.txt", "Assets/level3.txt", "Assets/level4.txt"};
    unsigned int level;

    // Test
    float testx, testy;

    Board* board;
    Paddle* paddle;
    Ball* ball;
    bool paddlestick;

    UI* score;
    UI* winlose;
    UI* lives;
    int currScore;
    int currLives;

    bool gameWon;
    bool gameLost;

    ///Frees up all of the data and memory
    void Clean();
    ///Updates the game 
    void Update(float delta);
    ///Renders the game
    void Render(float delta);
    ///Makes a new general board if there is no filepath
    void NewGame();
    ///Makes a new board from the given text file
    void NewGame(string filepath);
    ///Puts the paddle in the middle of the screen and the ball on top of that
    void ResetPaddle();
    ///Makes it so that the ball stays on the paddle
    void StickBall();
    ///Sets the paddle's x position
    void SetPaddleX(float x);
    ///Checks the borders of the window to see if the ball has hit them
    void CheckBoardCollisions();
    ///Figures out where the ball should be after a reflection
    float GetReflection(float hitx);
    ///Checks the position of the paddle to see if the ball is hitting it
    void CheckPaddleCollisions();
    ///Checks the positions of the bricks to see if they're being hit
    void CheckBrickCollisions();
    ///Checks the bricks to see if they are being hit
    void CheckBrickCollisions2();
    ///Bounces the ball off of the bricks
    void BallBrickResponse(int dirindex);
    ///Returns the total number of bricks in a given level
    int GetBrickCount();
};

#endif
