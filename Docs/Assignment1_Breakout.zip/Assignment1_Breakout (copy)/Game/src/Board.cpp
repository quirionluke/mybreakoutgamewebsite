// ------------------------------------------------------------
// The Breakout Tutorial
// (c) 2015 Rembound.com
// http://rembound.com/articles/the-breakout-tutorial
// ------------------------------------------------------------

#include "Board.hpp"

Board::Board(SDL_Renderer* renderer): Entity(renderer) {
    SDL_Surface* surface = IMG_Load("Assets/bricks.png");
    bricktexture = SDL_CreateTextureFromSurface(renderer, surface);
    SDL_FreeSurface(surface);

    surface = IMG_Load("Assets/side.png");
    sidetexture = SDL_CreateTextureFromSurface(renderer, surface);
    SDL_FreeSurface(surface);

    srand(time(0));

    x = 16;
    y = 0;
    width = 768;
    height = 600;

    brickoffsetx = 0;
    brickoffsety = 16;
}

Board::~Board() {
    // Clean resources
    SDL_DestroyTexture(bricktexture);
    SDL_DestroyTexture(sidetexture);
}

void Board::Update(float delta) {

}

void Board::Render(float delta) {
    // Render bricks
    for (int i=0; i<BOARD_WIDTH; i++) {
        for (int j=0; j<BOARD_HEIGHT; j++) {
            Brick brick = bricks[i][j];

            // Check if the brick exists
            if (!brick.state)
                continue;

            SDL_Rect srcrect;

            srcrect.x = BOARD_BRWIDTH;
            srcrect.y = BOARD_BRHEIGHT;
            srcrect.w = BOARD_BRWIDTH;
            srcrect.h = BOARD_BRHEIGHT;

            SDL_Rect dstrect;
            dstrect.x = brickoffsetx + x + i * BOARD_BRWIDTH;
            dstrect.y = brickoffsety + y + j * BOARD_BRHEIGHT;
            dstrect.w = BOARD_BRWIDTH;
            dstrect.h = BOARD_BRHEIGHT;

            SDL_RenderCopy(renderer, bricktexture, &srcrect, &dstrect);
        }
    }

    // Render sides
    SDL_Rect dstrect;
    dstrect.x = 0;
    dstrect.y = 0;
    dstrect.w = 16;
    dstrect.h = 600;
    SDL_RenderCopy(renderer, sidetexture, 0, &dstrect);

    dstrect.x = 800 - 16;
    dstrect.y = 0;
    dstrect.w = 16;
    dstrect.h = 600;
    SDL_RenderCopy(renderer, sidetexture, 0, &dstrect);
}

void Board::CreateLevel() {
    for (int i=0; i<BOARD_WIDTH; i++) {
        for (int j=0; j<BOARD_HEIGHT; j++) {
            Brick brick;

            brick.type = rand() % 4;    // Random color
            //brick.type = (i ^ j) % 4; // Example of a fixed pattern using xor
            brick.state = true;         // Brick is present
            bricks[i][j] = brick;
        }
    }
}


//must be contained in a 12x12 grid
void Board::CreateLevel(string filename) {
    string filecontent = "";
    string line;

    ifstream myfile;

    myfile.open(filename);

    if(myfile.is_open()){
        int i = 0;
        while(getline(myfile,line)) {
            Brick brick;

            for(int j = 0; j < line.length(); j++) {
                brick.type = rand() %4;
                if(line[j] == '1') {
                    brick.state = true;
                }
                else {
                    brick.state = false;
                }
                bricks[j][i] = brick;
            }
            i++;

            
        }
        myfile.close();
    }
    else {
        CreateLevel();
    }
}
